from django.urls import path
from . import views
# from django.contrib.auth import views as auth_views
from oauth2_provider.views import TokenView
from .views import LoginView, custom_token_obtain_pair, SaveUser, SaveQuestions

urlpatterns = [
    path('',views.index,name='index'),
    # path('api/login/', views.login, name='login'),
    path('api/token/', custom_token_obtain_pair, name='token_obtain_pair'),
    path('api/forgot_password/', views.forgot_password, name='forgot_password'),    
    path('api/dashboard/', views.dashboard, name='dashboard'),
    path('newCustomer/', views.newCustomer, name='newCustomer'),  
    path('o/token/', TokenView.as_view(), name='token'), 
    path('send-otp/', views.send_otp, name='send_otp'),
    path('reset_password/', views.reset_password, name='reset_password'),
    path('verify-otp/', views.verify_otp, name='verify_otp'),
    path('api/login/', LoginView.as_view(), name='login'),
    path('api/add_user_details/', SaveUser.as_view(), name='add_user'),
    path('api/save_questions/', SaveQuestions.as_view(), name='save_questions'),
    path('api/get_survey/', views.get_survey, name='get_survey'),
    path('api/get_survey/get_questions/<int:index>/', views.get_questions, name='get_questions'),
    path('api/get_survey/save_answer/', views.save_answer, name='save_answer'),
    path('api/conversion/', views.conversion, name='conversion'),
    path('api/fetch_question/', views.fetch_question, name='fetch_question'),
    path('api/read_excel/', views.read_excel, name='read_excel'), # reading excel file and saving data in database
    path('api/take_survey/', views.take_survey, name='take_survey'),
    path('api/take_survey/<str:category>/', views.take_survey, name='take_survey'),
    path('api/take_survey/<str:category>/<str:direction>/', views.take_survey, name='take_survey'),
    path('api/get_question/<str:direction>/', views.get_question, name='get_question'), # fetch question  one by one when api hits(front and back)
    path('api/get_question_index/<int:index>/', views.get_question_index, name='get_question_index'), # fetch question  one by one when api hits(index based)
    path('api/submit_answer/', views.submit_answer, name='submit_answer'),
    path('api/file/', views.file, name='file'), # upload a file which needs to be stored
    path('api/file/save_file/', views.save_file, name='save_file'), # save the entire file
    path('api/list_files/', views.list_files, name='list_files'), # list the files
    path('api/download_file/<str:file_name>/', views.download_file, name='download_file'), # download the file
    path('api/get_excel_data/', views.get_excel_data, name='get_excel_data'),
    path('api/get_ques/<str:direction>', views.get_ques, name='get_ques'),
]       