from rest_framework.response import Response
from django.http import JsonResponse
from .models import CompanyDetails

class AddCustomerData:
    def __init__(self,data):
        self.data = data
        self.add_customer_data()

    def add_customer_data(self):
        data_to_save = CompanyDetails(
            company_name = self.data['company_name'],
            company_type = self.data['company_type'],
            company_location = self.data['company_location'],
            street = self.data['street'],
            country = self.data['country'],
            city = self.data['city'],
            zip_code = self.data['zipcode'],
        )
        data_to_save.save()
        