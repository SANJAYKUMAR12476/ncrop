from django.contrib import admin
from .models import File_Uploads,Companies_Type,CustomUser, CompanyDetails, ContactDetails, ContactDirectory, LocationDetails, Milestone, Documents,Questions,ReadQuestions, SaveAnswer, f_Update, MainQuestions, SubQuestions
# from oauth2_provider.models import Application


# admin.site.register(Application)

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ['username', 'email', 'is_active', 'is_staff']

@admin.register(CompanyDetails)
class CompanyDetails(admin.ModelAdmin):
    list_display = ['company_name', 'company_type', 'company_location', 'street', 'country', 'city', 'zip_code']

@admin.register(ContactDetails)
class ContactDetails(admin.ModelAdmin):
    list_display = ['company_details', 'contact_person_name', 'contact_person_email', 'contact_person_designation', 'contact_person_mobile_number']

@admin.register(ContactDirectory)
class ContactDirectory(admin.ModelAdmin):
    list_display = ['contact_details', 'name', 'department', 'email', 'mobile_num']

@admin.register(LocationDetails)
class LocationDetails(admin.ModelAdmin):
    list_display = ['plant_name','street', 'country', 'city', 'zip_code']

@admin.register(Milestone)
class Milestone(admin.ModelAdmin):
    list_display = ['project_expectation']

@admin.register(Documents)
class Documents(admin.ModelAdmin):
    list_display = ['category','descriptions', 'document']

@admin.register(Questions)
class Questions(admin.ModelAdmin):
    list_display = ['serial_num','category','question_type', 'question', 'response']

@admin.register(ReadQuestions)
class ReadQuestions(admin.ModelAdmin):
    list_display = ['main_category','sub_category','condition','link','serial_num', 'type', 'question', 'options']

@admin.register(SaveAnswer)
class SaveAnswer(admin.ModelAdmin):
    list_display = ['response']

@admin.register(f_Update)
class f_Update(admin.ModelAdmin):
    list_display = ['filename','file_data','file_type','description']


@admin.register(Companies_Type)
class Companies_Type(admin.ModelAdmin):
    list_display = ['company_type', 'version']

@admin.register(File_Uploads)
class File_Uploads(admin.ModelAdmin):
    list_display = ['company_type', 'filename', 'file_data','file_type','description']
# @admin.register(uploadQuestions)
# class uploadQuestions(admin.ModelAdmin):
#     list_display = ['serial_num','category','question','options','answer']

@admin.register(MainQuestions)
class MainQuestions(admin.ModelAdmin):
    list_display = ['main_category','sub_category','condition','link','serial_num', 'type', 'question', 'options']

@admin.register(SubQuestions)
class SubQuestions(admin.ModelAdmin):
    list_display = ['main_category','sub_category','condition','link','serial_num', 'type', 'question', 'options']

# @admin.register(SaveFile)
# class SaveFile(admin.ModelAdmin):
#     list_display = ['document']