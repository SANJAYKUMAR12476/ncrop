from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http import JsonResponse
import json
from django.views.decorators.csrf import csrf_exempt
from .models import CustomUser, CompanyDetails, ContactDetails, Questions, ReadQuestions,SaveAnswer, Upload, sample,MainQuestions,SubQuestions
from django.conf import settings
from .addCustomerData import AddCustomerData
from django.shortcuts import render
from django.utils.crypto import get_random_string
from .models import OTP
from django.contrib.auth.hashers import make_password
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from .savedata import AddCustomer
from rest_framework_simplejwt.views import TokenObtainPairView
import pandas as pd
import excel2json
from django.http import JsonResponse
import ast
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

custom_token_obtain_pair = TokenObtainPairView.as_view()
last_sent_question_id = 0


def index(request):
    return render(request, 'index.html')


@csrf_exempt
def api_login(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body)
            username = data.get('username')
            password = data.get('password')
            user_details = CustomUser.objects.all()
            for detail in user_details:
                if username == detail.username and password == detail.password:
                    settings.ROLE = detail.role
                    request.session['authenticated'] = True
                    return JsonResponse({'success': True})
            # user = authenticate(username=username, password=password)
        else:
            return JsonResponse({'error': 'Invalid request method'})
        return JsonResponse({'error': 'no user id matched'})
    except Exception as e:
        return JsonResponse({'error':e})

def dashboard(request):
    authenticated = request.session.get('authenticated', False)
    if authenticated:
        return render(request,'dashboard.html')

@csrf_exempt
def newCustomer(request):
    try:
        if request.method == 'POST':
            data = json.loads(request.body)
            retrieved_data ={'company_name' : data.company_name,
                             'company_type' : data.company_type,
                             'company_location': data.company_location,
                             'street' : data.street,
                             'country' : data.country,
                             'city' : data.city,
                             'zipcode' : data.zipcode
                             }
            custom_object = AddCustomerData(retrieved_data)
            return JsonResponse({'result':'Customer Data Added'})
    except Exception as e:
        return JsonResponse({'error':e})

def forgot_password(request):
    return render(request,'forgot_password.html')


def send_otp(request):
    if request.method == 'POST':
        receiver_email  = request.POST['email']
        user_name = request.POST['username']
        sender_email = 'chan23chandru@gmail.com'
        body = 'This is a test email sent from a Python script.'
        try:
            user = CustomUser.objects.get(email=receiver_email,username = user_name)
        except Exception as e:
             return render(request,'forgot_password.html')
        otp_code = get_random_string(length=6, allowed_chars='1234567890')
        OTP.objects.update_or_create(custom_user=user, defaults={'otp': otp_code})
        message = MIMEMultipart()
        message['From'] = sender_email
        message['To'] = receiver_email
        message['Subject'] = otp_code
        message.attach(MIMEText(body, 'plain'))
        try:
            with smtplib.SMTP('smtp.gmail.com',587) as server:
                server.starttls()
                server.login(sender_email, 'czzp zuig mjtw rqde')
                server.sendmail(sender_email, receiver_email, message.as_string())
                return render(request, 'verify_otp.html', {'email': receiver_email})
        except Exception as e:
            return render(request, 'forgot_password.html')

        

def verify_otp(request):
    if request.method == 'POST':
        email = request.POST['email']
        otp_entered = request.POST['otp']
        user = CustomUser.objects.get(email=email)
        otp_obj = OTP.objects.get(custom_user=user)
        if otp_entered == otp_obj.otp:
            new_password = get_random_string(length=12) 
            user.password = make_password(new_password)
            request.session['user_id'] = user.id
            user.save()
            otp_obj.delete()
            return render(request, 'password_reset.html', {'new_password': new_password})
        else:
            return render(request, 'verify_otp.html', {'email': email, 'error_message': 'Invalid OTP'})

    return render(request, 'verify_otp.html')

def reset_password(request):
    if request.method == 'POST':
        new_password = request.POST['new_password']
        confirm_password = request.POST['confirm_password']
        if new_password == confirm_password:
            user_id = request.session.get('user_id')
            if user_id:
                user = CustomUser.objects.get(id=user_id)
                user.password = new_password
                user.save()
                return render(request,'password_reset_success.html')
            else:
                return render(request,'user_not_found.html')
    return render(request, 'password_reset.html')


class LoginView(APIView):
    global username
    def post(self, request, *args, **kwargs):
        try:
            if request.method == 'POST':
                user_credentials = request.data  
                username = user_credentials.get('username')
                password = user_credentials.get('password')
                user_details = CustomUser.objects.all()
                for detail in user_details:
                    if username == detail.email and password == detail.password:
                        settings.ROLE = detail.role
                        request.session['authenticated'] = True
                        return Response({"message": "Login successful"}, status=status.HTTP_200_OK)
                return Response({'error': 'Invalid request method'},status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'error': 'Invalid request method'},status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error':e},status=status.HTTP_400_BAD_REQUEST)

class SaveUser(APIView):
    def post(self,request,*args,**kwargs):
        try:
            if request.method == 'POST':
                customer_detail = request.data.get('userDetails', {})
                contact_detail = request.data.get('contactdetail',{})
                contact_directory = request.data.get('contactdirectory',{})
                location_detail = request.data.get('locationdetail',{})
                user_instance = CustomUser.objects.get(email=username)
                company_instance = CompanyDetails.objects.get(custom_user = user_instance)
                contact_instance = ContactDetails.objects.get(company_details = company_instance)
                AddCustomer.save_company_data(customer_detail,user_instance)
                AddCustomer.save_contact(contact_detail,company_instance)
                AddCustomer.save_directory(contact_directory,contact_instance)
                AddCustomer.save_location(location_detail,company_instance)
            else:
                return Response({'error': 'Invalid request method'},status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error':e},status=status.HTTP_400_BAD_REQUEST)
        
class SaveQuestions(APIView):
    def get(self,request,*args,**kwargs):
        try:
            excel_file_path = 'C:\\Users\\NCV_C\\Desktop\\sampel_questions.xlsx'
            df = pd.read_excel(excel_file_path)
            sample_dict = {}
            test_list = []
            for index, row in df.iterrows():
                sample_dict['s_no'] = str(row['S. No.'])
                sample_dict['category'] = row['Category']
                sample_dict['Question'] = row['Questionnaire']
                row['Response'] = row['Response'] if type(row['Response']) == str else str(row['Response'])
                sample_dict['Response'] = row['Response'].split('/') if not pd.isna(row['Response']) else 'Text'
                test_list.append(sample_dict)
                sample_dict = {}
            for sample in test_list:
                new_question = Questions (
                    serial_num = str(sample['s_no']),
                    category = sample['category'],
                    question = sample['Question'],
                    response = sample['Response'],
                    answers = '',
                )
                new_question.save()
            return Response({'success':'data saved successfully'})
        except Exception as e:
            return Response({'error':e})

def get_survey(request):
    return render(request,'fetch_questions.html')

def get_questions(request,index):
    questions= Questions.objects.all()
    questions_data = [{'text': q.question,'id':q.serial_num, 'category': q.category, 'options':ast.literal_eval(q.response.replace("'", '"'))} for q in questions]
    # sample = [
    # {
    #     "text": "Wdhat is your favorite color?",
    #     "options": ["Red", "Blue", "Green", "Yellow"]
    # },
    # {
    #     "text": "How often do you exercise?",
    #     "options": ["Never", "Rarely", "Sometimes", "Frequently"]
    # },
    # ]
    return JsonResponse({'questions': questions_data[index]})   

from django.shortcuts import get_object_or_404

@csrf_exempt
def save_answer(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))
        question_index = data.get('questionIndex')
        answer1 = data.get('answer')
        response_data = {'message': 'Answer saved successfully'}
        return JsonResponse(response_data)
    response_data = {'message': 'Invalid request method'}
    return JsonResponse(response_data, status=400)

from django.shortcuts import render, redirect



# def upload_file(request):
#     if request.method == 'POST':
#         form = FileUploadForm(request.POST, request.FILES)
#         if form.is_valid():
#             form.save()
#             return redirect('file_upload_success')
#     else:
#         form = FileUploadForm()
#     return render(request, 'fileuploadapp/upload.html', {'form': form})




# def conversion(request):
#     excel_file_path = 'C:\\Users\\NCV_C\\Desktop\\sampel_questions.xlsx'
#     json_data = None
#     try:
#         df = pd.read_excel(excel_file_path, sheet_name='Sheet1')
#         json_data = df.to_json(orient='records')
        
#     except Exception as e:
#         json_data = {'error------------------>': str(e)}
#     return JsonResponse({'data': json_data})
import pandas as pd
from django.http import JsonResponse

import pandas as pd
from django.http import JsonResponse

def remove_nan(json_obj):
    if isinstance(json_obj, dict):
        return {k: remove_nan(v) for k, v in json_obj.items() if not pd.isna(v)}
    elif isinstance(json_obj, list):
        return [remove_nan(item) for item in json_obj]
    else:
        return json_obj

def conversion(request):
    excel_file_path = 'C:\\Users\\NCV_C\\Desktop\\sampel_questions.xlsx'
    json_data = None

    try:
        df = pd.read_excel(excel_file_path, sheet_name='Sheet1')
        data_dict = df.to_dict(orient='records')
        cleaned_data = [remove_nan(item) for item in data_dict]
        options = []
        result = []
        for data in cleaned_data:
            if 'S.No.' in data.keys():
                if data['Type']:
                    result.append({
                        's_no':data['S.No.'] if data['S.No.'] else None,
                        'question' : data['Questionnaire'] if data['Questionnaire'] else None,
                        'type': data['Type'] if data['Type'] else None,
                        'category': data['Category'] if data['Category'] else None,
                        'option':options if len(options) else ['Text']
                    })
                    options = []            
            else:
                options.append(data['Response'])
        json_data = {'data': 'data fetched from excel'}
        if result:
            for data in result:
                question_to_save = Questions(
                    serial_num = data['s_no'],
                    category = data['category'],
                    question_type = data['type'],
                    question = data['question'],
                    response = data['option'],
                    answers = 'None'
                )
                question_to_save.save()
                json_data = {'data': 'data saved successfully'}
    except Exception as e:
        json_data = {'error': str(e)}
    return JsonResponse(json_data)
  
def fetch_question(request):

    current_question_number = request.session.get('current_question_number', 1)
    try:
        current_question = Questions.objects.all()
    except Questions.DoesNotExist:
        return JsonResponse({'message': 'No more questions'}) 

    question_data = {
        'question_number': current_question.serial_num,
        'question_text': current_question.question,
        'options': current_question.response.split(','),
    }
    request.session['current_question_number'] = current_question_number + 1

    return JsonResponse(question_data)

import xlrd
def read_excel(request):
    excel_file_path = 'C:\\Users\\NCV_C\\Desktop\\testing_cta.xlsx'
    json_data = None
    try:
        merged_data = []
        current_main_category, current_main_category, current_sub_category = (None, None, None)
        df = pd.read_excel(excel_file_path, sheet_name='sheet1')
        data_dict = df.to_dict(orient='records')
        cleaned_data = [remove_nan(item) for item in data_dict]
        for item in cleaned_data:
            if 'Main_Category' in item:
                current_main_category = item['Main_Category']
                merged_data.append({
                    'Main_Category': current_main_category,
                    'Sub_Categories': item['Sub_Category'],
                    'Questions': []
                })
                current_sub_category = None
            elif 'Sub_Category' in item:
                current_sub_category = item['Sub_Category']
                if current_main_category is not None:
                    merged_data[-1]['Sub_Categories'].append(current_sub_category)
            else:
                if current_main_category is not None:
                    options = item.get('Response', '')
                    merged_data[-1]['Questions'].append({
                        'S.No.': item.get('S.No.', ''),
                        'Condition':item.get('Condition','') ,
                        'Link':item.get('Document/Link',''),
                        'Type': item.get('Type', ''),
                        'Questionnaire': item.get('Questionnaire', ''),
                        'Response': options.split('🞺') if options else ['Text']
                    })
        sam = ReadQuestions
        json_data = merged_data
        try:
            if merged_data:
                for data in merged_data:
                    for question in data['Questions']:
                        read_questions = sam(
                            main_category=data['Main_Category'],
                            sub_category=data['Sub_Categories'],
                            serial_num=question['S.No.'],
                            condition=question.get('Condition', ''),
                            link=question.get('Link', ''),  
                            type=question['Type'],
                            question=question['Questionnaire'],
                            options=question['Response'],
                        )
                        read_questions.save()
            return JsonResponse({'message': 'Data processed and saved successfully'})
        except Exception as e:
            return JsonResponse({'error': 'An error occurred while processing the data.'})


    except Exception as e:
        json_data = {'error': str(e)}
    return JsonResponse({'data':json_data})

def take_survey(request,category=None,direction=None):
    try:
        categories = ReadQuestions.objects.all()
        sample_dict = {}
        for data in categories:
            main_category = data.main_category
            sub_category = data.sub_category

            if main_category not in sample_dict:
                sample_dict[main_category] = []

            if sub_category not in sample_dict[main_category]:
                sample_dict[main_category].append(sub_category)
        if category:
            if direction:
                return JsonResponse({'data':get_question(request,direction)})
            return JsonResponse({'data':fetch_category(category)})
        return Response(sample_dict)
    except Exception as e:
        return JsonResponse({'error':e})
    
from django.db.models import Q
def fetch_category(category):
    try:
        question_list = ReadQuestions.objects.all()
        ques = question_list.filter(Q(main_category=category) | Q(sub_category=category))
        data = None
        result = []
        number_of_questions = ReadQuestions.objects.count()
        if ques:
            for data in ques:
                result.append({
                    'position' : str(data.serial_num) + '/' + str(number_of_questions),
                    'question': data.question,
                    'options':data.options,
                    'answer_type' : data.type
                })
                break
        return result
    except Exception as e:
        return JsonResponse({'error':e})

from rest_framework.decorators import api_view
@api_view(['GET'])
def get_question(request,direction):
    global last_sent_question_id
    try:
        next_question= None
        number_of_questions = ReadQuestions.objects.count()
        if direction == 'next':
            next_question = ReadQuestions.objects.filter(id__gt=last_sent_question_id).order_by('id').first()
            if request.method == 'POST':
                question_id = request.POST.get('question_id')
                response = request.POST.get('response')
                question = ReadQuestions.objects.filter(id=question_id).first()
                if not question:
                    return JsonResponse({'message': 'Question not found'}, status=404)
                if response:
                    answer = SaveAnswer(question=question, response=response)
                    answer.save()
                # if response == 'Yes':
                #     # Find the subquestion based on the hierarchy
                #     subquestion = QuestionHierarchy.objects.filter(parent_question=question).first()
                #     if subquestion:
                #         next_question = subquestion.child_question
                # elif response == 'No':
                #     # Find the alternate question based on the hierarchy
                #     alternate_question = QuestionHierarchy.objects.filter(parent_question=question, child_question__isnull=False).first()
                #     if alternate_question:
                #         next_question = alternate_question.child_question
                # SaveAnswer.objects.filter(question__id__gt=last_sent_question_id).delete()
        elif direction == 'back':
            previous_question = ReadQuestions.objects.filter(id__lt=last_sent_question_id).order_by('-id').first()
            if previous_question:
                last_sent_question_id = previous_question.id
                question_data = {
                        'question_num': str(previous_question.serial_num) + '/' + str(number_of_questions),
                        'serial_num':previous_question.serial_num,
                        'main_cat': previous_question.main_category,
                        'sub_cat':previous_question.sub_category,
                        'type': previous_question.type,
                        'question': previous_question.question,
                        'options': previous_question.options,
                }
                return Response(question_data)
            else:
                return JsonResponse({'message': 'No previous question available'}, status=404)
        else:
            return JsonResponse({'message': 'Invalid direction'}, status=400)

        if next_question is not None:
            last_sent_question_id = next_question.id
            question_data = {
                'question_num': str(next_question.serial_num) + '/' + str(number_of_questions),
                'serial_num':next_question.serial_num,
                'main_cat': next_question.main_category,
                'sub_cat':next_question.sub_category,
                'type': next_question.type,
                'question': next_question.question,
                'options': next_question.options
            }
            return Response(question_data)
        else:
            return JsonResponse({'message': 'No more questions available'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
    
@csrf_exempt
@api_view(['POST'])
def submit_answer(request):
    question_id = request.data.get('questionId')
    question_text = request.data.get('questionText')
    selected_answers = request.data.get('selectedAnswers')
    try:
        read_question = ReadQuestions.objects.get(serial_num=question_id, question=question_text)
        if read_question:
            save_answer = SaveAnswer(question=read_question, response=selected_answers)
            save_answer.save()
            return JsonResponse({'data':'success'})
    except ReadQuestions.DoesNotExist:
        print("Question not found")

def file(request):
    return render(request,'file_upload.html')

@csrf_exempt
def save_file(request):
    try:
        uploaded_file = request.FILES['file']
        file_data = uploaded_file.read()
        filename = uploaded_file.name
        file_type = uploaded_file.content_type
        sample.objects.create(
            filename=filename,
            file_data=file_data,
            file_type=file_type,
        )
        return JsonResponse({'message': 'File uploaded successfully.'})
    except Exception as e:
        return JsonResponse({'message': str(e)}, status=400)

def list_files(request):
    file_entry = sample.objects.all()
    list = []
    for data in file_entry:
        filename = data.filename
        list.append(filename)
    return JsonResponse({'file_list': list})
 
from django.http import HttpResponse
def download_file(request,file_name):
    try:
        file_entry = sample.objects.get(filename = file_name)
        file_data = file_entry.file_data
        filename = file_entry.filename
        response = HttpResponse(file_data, content_type='application/octet-stream')
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        return HttpResponse('response')
    except sample.DoesNotExist:
        return HttpResponse('File not found', status=404) 

def get_question_index(request,index):
    try:
        ind = str(index)+'.0'
        ques = ReadQuestions.objects.get(serial_num = ind)
        number_of_questions = ReadQuestions.objects.count()
        q_num = ques.serial_num
        if '.0' in q_num:
            num = q_num.split('.')
            q_num = num[0]
        position = q_num +'/'+str(number_of_questions)
        if index != 0:
            return JsonResponse({
                        'question_num': position,
                        'serial_num':ques.serial_num,
                        'main_cat': ques.main_category,
                        'sub_cat':ques.sub_category,
                        'type': ques.type,
                        'question': ques.question,
                        'options': ques.options
                })
    except Exception as e:
        return JsonResponse({'error':e})

def get_files(request):
    try:
        if request.method == 'POST':
            value = request.data
            file_name = value.get('file_name','')
            data = value.get('file_column','')
            file_data = value.get('file_data','')
            for i in file_data:
                sample.append(file_name)
                sample.append(data)
            return JsonResponse({'data':sample})
        else:
            return JsonResponse({'error':'method is not correct'})
    except Exception as e:
        return JsonResponse({'error':e})
    


def get_excel_data(request):
    excel_file_path = 'C:\\Users\\NCV_C\\Desktop\\testing_cta.xlsx'
    try:
        merged_data = []
        current_main_category, current_main_category, current_sub_category = (None, None, None)
        df = pd.read_excel(excel_file_path, sheet_name='sheet1')
        data_dict = df.to_dict(orient='records')
        cleaned_data = [remove_nan(item) for item in data_dict]
        for item in cleaned_data:
            if 'Main_Category' in item:
                current_main_category = item['Main_Category']
                merged_data.append({
                    'Main_Category': current_main_category,
                    'Sub_Categories': item['Sub_Category'],
                    'Questions': []
                })
                current_sub_category = None
            elif 'Sub_Category' in item:
                current_sub_category = item['Sub_Category']
                if current_main_category is not None:
                    merged_data[-1]['Sub_Categories'].append(current_sub_category)
            else:
                if current_main_category is not None:
                    options = item.get('Response', '')
                    merged_data[-1]['Questions'].append({
                        'S.No.': item.get('S.No.', ''),
                        'Condition':item.get('Condition','') ,
                        'Link':item.get('Document/Link',''),
                        'Type': item.get('Type', ''),
                        'Questionnaire': item.get('Questionnaire', ''),
                        'Response': options.split('🞺') if options else ['Text']
                    })
        try:
            if merged_data:
                for data in merged_data:
                    for question in data['Questions']:
                        if '.0' in str(question['S.No.']):
                            main_question = MainQuestions(
                                main_category=data['Main_Category'],
                                sub_category=data['Sub_Categories'],
                                serial_num=question['S.No.'],
                                condition=question.get('Condition', ''),
                                link=question.get('Link', ''),  
                                type=question['Type'],
                                question=question['Questionnaire'],
                                options=question['Response'],
                            )
                            main_question.save()
                        else:
                            sub_question = SubQuestions(
                                main_questions = main_question,
                                main_category=data['Main_Category'],
                                sub_category=data['Sub_Categories'],
                                serial_num=question['S.No.'],
                                condition=question.get('Condition', ''),
                                link=question.get('Link', ''),  
                                type=question['Type'],
                                question=question['Questionnaire'],
                                options=question['Response'],
                            )
                            sub_question.save()
            return JsonResponse({'message': 'Data processed and saved successfully'})
        except Exception as e:
            return JsonResponse({'error----->': e})
    except Exception as e:
        return JsonResponse({'error':e})

from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http import JsonResponse
from .models import MainQuestions, SubQuestions, ReadQuestions, SaveAnswer


# Initialize global variables
# last_sent_question_id = Nos

# @api_view(['GET', 'POST'])
# def get_ques(request, direction):
#     global last_sent_question_id, value    
#     try:
#         next_question = None
#         number_of_questions = ReadQuestions.objects.count()

#         if direction == 'next':
#             print('******',last_sent_question_id)
#             next_question = ReadQuestions.objects.filter(id__gt=last_sent_question_id).order_by('id').first()
#             value = False
#             if request.method == 'POST':
#                 question_id = request.POST.get('question_id')
#                 response = request.POST.get('response')
#                 question = ReadQuestions.objects.filter(id=question_id).first()

#                 if not question:
#                     return JsonResponse({'message': 'Question not found'}, status=404)

#                 if response:
#                     answer = SaveAnswer(question=question, response=response)
#                     answer.save()
#             if next_question.condition:
#                 if next_question.serial_num.is_integer():
#                     value = True
#                     sample = ReadQuestions.objects.values_list('serial_num', flat=True)
#                     count = 0
#                     val = next_question.serial_num
#                     print(list(sample))
#                     count = 0
#                     while True:
#                         next_val = val + 0.1
#                         if any(abs(next_val - x) < 1e-9 for x in sample):
#                             count += 1
#                             val = next_val
#                         else:
#                             break

#         elif direction == 'back':
#             value = False
#             count = 0
#             previous_question = ReadQuestions.objects.filter(id__lt=last_sent_question_id).order_by('-id').first()
#             print(last_sent_question_id)
#             if previous_question:
#                 last_sent_question_id = previous_question.id
#                 question_data = {
#                     'question_num': str(previous_question.serial_num) + '/' + str(number_of_questions),
#                     'serial_num': previous_question.serial_num,
#                     'main_cat': previous_question.main_category,
#                     'sub_cat': previous_question.sub_category,
#                     'type': previous_question.type,
#                     'question': previous_question.question,
#                     'options': previous_question.options,
#                 }
#                 return Response(question_data)
#             else:
#                 return JsonResponse({'message': 'No previous question available'}, status=404)
#         else:
#             return JsonResponse({'message': 'Invalid direction'}, status=400)

#         if next_question is not None:
#             last_sent_question_id = next_question.id
#             question_data = {
#                 'question_num': str(next_question.serial_num) + '/' + str(number_of_questions),
#                 'serial_num': next_question.serial_num,
#                 'main_cat': next_question.main_category,
#                 'sub_cat': next_question.sub_category,
#                 'type': next_question.type,
#                 'question': next_question.question,
#                 'options': next_question.options,
#             }
#             if value:
#                 last_sent_question_id += count
#             else:
#                 last_sent_question_id = next_question.id
#             return Response(question_data)
#         else:
#             return JsonResponse({'message': 'No more questions available'}, status=404)
#     except Exception as e:
#         return JsonResponse({'error': str(e)}, status=500)



@api_view(['GET', 'POST'])
def get_ques(request, direction):
    global last_sent_question_id, value, count    
    try:
        next_question = None
        number_of_questions = ReadQuestions.objects.count()

        if direction == 'next':
            print('******', last_sent_question_id)
            next_question = ReadQuestions.objects.filter(id__gt=last_sent_question_id).order_by('id').first()
            if request.method == 'POST':
                question_id = request.POST.get('question_id')
                response = request.POST.get('response')
                question = ReadQuestions.objects.filter(id=question_id).first()

                if not question:
                    return JsonResponse({'message': 'Question not found'}, status=404)

                if response:
                    answer = SaveAnswer(question=question, response=response)
                    answer.save()

            if next_question.condition:
                if next_question.serial_num.is_integer():
                    value = True
                    sample = ReadQuestions.objects.values_list('serial_num', flat=True)
                    count = 0
                    val = next_question.serial_num
                    print(list(sample))
                    while True:
                        next_val = val + 0.1
                        if any(abs(next_val - x) < 1e-9 for x in sample):
                            count += 1
                            val = next_val
                        else:
                            break

        elif direction == 'back':
            previous_question = ReadQuestions.objects.filter(id__lt=last_sent_question_id).order_by('-id').first()
            if previous_question:
                if value and count > 0:
                    # Skip subquestions by adjusting last_sent_question_id
                    last_sent_question_id = previous_question.id - count
                else:
                    last_sent_question_id = previous_question.id

                question_data = {
                    'question_num': str(previous_question.serial_num) + '/' + str(number_of_questions),
                    'serial_num': previous_question.serial_num,
                    'main_cat': previous_question.main_category,
                    'sub_cat': previous_question.sub_category,
                    'type': previous_question.type,
                    'question': previous_question.question,
                    'options': previous_question.options,
                }
                return Response(question_data)
            else:
                return JsonResponse({'message': 'No previous question available'}, status=404)
        else:
            return JsonResponse({'message': 'Invalid direction'}, status=400)

        if next_question is not None:
            last_sent_question_id = next_question.id
            question_data = {
                'question_num': str(next_question.serial_num) + '/' + str(number_of_questions),
                'serial_num': next_question.serial_num,
                'main_cat': next_question.main_category,
                'sub_cat': next_question.sub_category,
                'type': next_question.type,
                'question': next_question.question,
                'options': next_question.options,
            }
            if value:
                last_sent_question_id += count
            else:
                last_sent_question_id = next_question.id
            return Response(question_data)
        else:
            return JsonResponse({'message': 'No more questions available'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)







#     global last_sent_question_id, current_subquestion_id

#     try:
#         number_of_questions = MainQuestions.objects.count()

#         if direction == 'next':
#             current_main_question = None
#             next_subquestion = None

#             if last_sent_question_id is None:
#                 # If last_sent_question_id is not set, start with the first main question
#                 current_main_question = MainQuestions.objects.filter(condition=True).first()
#             else:
#                 # If last_sent_question_id is set, get the current main question
#                 current_main_question = MainQuestions.objects.filter(id=last_sent_question_id).first()

#             if request.method == 'POST':
#                 question_id = request.data.get('question_id')
#                 response = request.data.get('response')
#                 question = ReadQuestions.objects.filter(id=question_id).first()

#                 if not question:
#                     return JsonResponse({'message': 'Question not found'}, status=404)

#                 if response:
#                     answer = SaveAnswer(question=question, response=response)
#                     answer.save()

#             if current_main_question:
#                 if current_main_question.condition and current_subquestion_id is None:
#                     # If the current main question has a condition and there's no subquestion in progress
#                     next_subquestion = get_next_subquestion(current_main_question)
#                     if next_subquestion:
#                         # Return the next subquestion if available
#                         question_data = {
#                             'question_num': f'{next_subquestion.serial_num}/{number_of_questions}',
#                             'serial_num': next_subquestion.serial_num,
#                             'main_cat': next_subquestion.main_category,
#                             'sub_cat': next_subquestion.sub_category,
#                             'type': next_subquestion.type,
#                             'question': next_subquestion.question,
#                             'options': next_subquestion.options,
#                             'subquestion_id': next_subquestion.id,
#                         }
#                         return Response(question_data)

#                 if current_main_question.condition and current_subquestion_id:
#                     # If there's a condition on the current main question and there's a subquestion in progress
#                     current_subquestion = SubQuestions.objects.filter(id=current_subquestion_id).first()
#                     next_subquestion = get_next_subquestion(current_main_question, current_subquestion)
#                     if next_subquestion:
#                         # Return the next subquestion if available
#                         question_data = {
#                             'question_num': f'{next_subquestion.serial_num}/{number_of_questions}',
#                             'serial_num': next_subquestion.serial_num,
#                             'main_cat': next_subquestion.main_category,
#                             'sub_cat': next_subquestion.sub_category,
#                             'type': next_subquestion.type,
#                             'question': next_subquestion.question,
#                             'options': next_subquestion.options,
#                             'subquestion_id': next_subquestion.id,
#                         }
#                         return Response(question_data)

#             # If no subquestion is available or the condition is not met, move to the next main question
#             next_main_question = MainQuestions.objects.filter(id__gt=last_sent_question_id, condition=True).first()

#             if next_main_question:
#                 last_sent_question_id = next_main_question.id
#                 question_data = {
#                     'question_num': f'{next_main_question.serial_num}/{number_of_questions}',
#                     'serial_num': next_main_question.serial_num,
#                     'main_cat': next_main_question.main_category,
#                     'sub_cat': next_main_question.sub_category,
#                     'type': next_main_question.type,
#                     'question': next_main_question.question,
#                     'options': next_main_question.options,
#                     'id': next_main_question.id,
#                 }
#                 return Response(question_data)

#         elif direction == 'back':
#             # Handle moving back to the previous question if needed
#             previous_question = MainQuestions.objects.filter(id__lt=last_sent_question_id, condition=True).order_by('-id').first()

#             if previous_question:
#                 last_sent_question_id = previous_question.id
#                 question_data = {
#                     'question_num': f'{previous_question.serial_num}/{number_of_questions}',
#                     'serial_num': previous_question.serial_num,
#                     'main_cat': previous_question.main_category,
#                     'sub_cat': previous_question.sub_category,
#                     'type': previous_question.type,
#                     'question': previous_question.question,
#                     'options': previous_question.options,
#                 }
#                 return Response(question_data)
#             else:
#                 return JsonResponse({'message': 'No previous question available'}, status=404)
#         else:
#             return JsonResponse({'message': 'Invalid direction'}, status=400)

#         # If no more questions are available
#         return JsonResponse({'message': 'No more questions available'}, status=404)

#     except Exception as e:
#         return JsonResponse({'error': str(e)}, status=500)

# def get_next_subquestion(main_question, current_subquestion=None):
    # if main_question.condition:
    #     if current_subquestion is None:
    #         # If no current subquestion, return the first subquestion of the main question
    #         sub_question = SubQuestions.objects.filter(main_questions=main_question).first()
    #         if sub_question:
    #             return sub_question
    #     else:
    #         # If a current subquestion is provided, find the next subquestion based on serial_num
    #         sub_question = SubQuestions.objects.filter(main_questions=main_question, serial_num__gt=current_subquestion.serial_num).first()
    #         if sub_question:
    #             return sub_question

    # # If no subquestion is available or the condition is not met, return None
    # return None




# from rest_framework.decorators import api_view
# @api_view(['GET', 'POST'])
# def get_ques(request,direction):
#     global last_sent_question_id
#     try:
#         next_question= None
#         number_of_questions = ReadQuestions.objects.count()
#         if direction == 'next':
#             next_question = MainQuestions.objects.filter(id__gt=last_sent_question_id).order_by('id').first()
#             if next_question.condition:
#                 next_questions = SubQuestions.objects.filter(main_questions = next_question)
#                 for ques in next_questions:
#                     question_data = {
#                     'question_num': str(ques.serial_num) + '/' + str(number_of_questions),
#                     'serial_num':ques.serial_num,
#                     'main_cat': next_question.main_category,
#                     'sub_cat':next_question.sub_category,
#                     'type': ques.type,
#                     'question': ques.question,
#                     'options': ques.options
#                     }
#                     return Response(question_data)
#             if request.method == 'POST':
#                 question_id = request.POST.get('question_id')
#                 response = request.POST.get('response')
#                 question = ReadQuestions.objects.filter(id=question_id).first()
#                 if not question:
#                     return JsonResponse({'message': 'Question not found'}, status=404)
#                 if response:
#                     answer = SaveAnswer(question=question, response=response)
#                     answer.save()

#                 # if response == 'Yes':
#                 #     # Find the subquestion based on the hierarchy
#                 #     subquestion = QuestionHierarchy.objects.filter(parent_question=question).first()
#                 #     if subquestion:
#                 #         next_question = subquestion.child_question
#                 # elif response == 'No':
#                 #     # Find the alternate question based on the hierarchy
#                 #     alternate_question = QuestionHierarchy.objects.filter(parent_question=question, child_question__isnull=False).first()
#                 #     if alternate_question:
#                 #         next_question = alternate_question.child_question
#                 # SaveAnswer.objects.filter(question__id__gt=last_sent_question_id).delete()
#         elif direction == 'back':
#             previous_question = MainQuestions.objects.filter(id__lt=last_sent_question_id).order_by('-id').first()
#             if previous_question:
#                 last_sent_question_id = previous_question.id
#                 question_data = {
#                         'question_num': str(previous_question.serial_num) + '/' + str(number_of_questions),
#                         'serial_num':previous_question.serial_num,
#                         'main_cat': previous_question.main_category,
#                         'sub_cat':previous_question.sub_category,
#                         'type': previous_question.type,
#                         'question': previous_question.question,
#                         'options': previous_question.options,
#                 }
#                 return Response(question_data)
#             else:
#                 return JsonResponse({'message': 'No previous question available'}, status=404)
#         else:
#             return JsonResponse({'message': 'Invalid direction'}, status=400)

#         if next_question is not None:
#             last_sent_question_id = next_question.id
            
#             question_data = {
#                 'question_num': str(next_question.serial_num) + '/' + str(number_of_questions),
#                 'serial_num':next_question.serial_num,
#                 'main_cat': next_question.main_category,
#                 'sub_cat':next_question.sub_category,
#                 'type': next_question.type,
#                 'question': next_question.question,
#                 'options': next_question.options
#             }
#             return Response(question_data)
#         else:
#             return JsonResponse({'message': 'No more questions available'}, status=404)
#     except Exception as e:
#         return JsonResponse({'error': str(e)}, status=500)
