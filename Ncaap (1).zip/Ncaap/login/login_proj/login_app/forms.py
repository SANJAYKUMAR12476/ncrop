# from django import forms
# from .models import UploadedFiles

# class FileUploadForm(forms.ModelForm):
#     class Meta:
#         model = UploadedFiles
#         fields = ['file']
