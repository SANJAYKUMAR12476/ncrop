from django.db import models

class CustomUser(models.Model):
    username = models.CharField(max_length=30, unique=True)
    email = models.EmailField(blank=True)
    password = models.CharField(max_length=128)
    role = models.CharField(max_length= 50, choices=[
        ('sales', 'Sales'),
        ('domain expert', 'Domain Expert'),
        ('admin','Admin'),
        ('consultant','Consultant')           
        ])
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    def __str__(self):
        return self.username
    
class OTP(models.Model):
    custom_user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    otp = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)

class ABC(models.Model):
    doc = models.FileField(upload_to='uploads/')

class CompanyDetails(models.Model):
    custom_user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=50, unique=True)
    company_type = models.CharField(max_length=50)
    company_location = models.CharField(max_length=53)
    street = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    zip_code = models.CharField(max_length=50)

    def __str__(self):
        return self.company_name
    
class ContactDetails(models.Model):
    company_details = models.OneToOneField(CompanyDetails, on_delete=models.CASCADE)
    contact_person_name = models.CharField(max_length=50)
    contact_person_email = models.CharField(max_length=50, unique=True)
    contact_person_designation = models.CharField(max_length=50)
    contact_person_mobile_number = models.CharField(max_length=50)
    
class ContactDirectory(models.Model):
    contact_details = models.ForeignKey(ContactDetails, on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    department = models.CharField(max_length=30)
    email = models.EmailField(max_length=30, unique=True)
    mobile_num = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class LocationDetails(models.Model):
    company_details = models.ForeignKey(CompanyDetails, on_delete=models.CASCADE)
    plant_name = models.CharField(max_length=30)
    street = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    zip_code = models.CharField(max_length=10)

    def __str__(self):
        return self.plant_name

class Milestone(models.Model):
    company_details = models.ForeignKey(CompanyDetails, on_delete=models.CASCADE)
    project_expectation = models.TextField(max_length=300)

    def __str__(self):
        return self.project_expectation

class Documents(models.Model):
    company_details = models.ForeignKey(CompanyDetails, on_delete=models.CASCADE)
    STATUS_CHOICES = [
        ('published', 'Published'),
        ('archived', 'Archived'),
    ]
    category = models.CharField(max_length=20, choices = STATUS_CHOICES)
    descriptions = models.CharField(max_length=100)
    document = models.FileField(upload_to='documents/')

    def __str__(self):
        return self.document
    
from django.contrib.postgres.fields import ArrayField
class Questions(models.Model):
    serial_num = models.CharField(max_length=100) 
    category = models.CharField(max_length=255)
    question_type = models.CharField(max_length=25, db_column='type')
    question = models.CharField(max_length=255)
    response = ArrayField(models.CharField(max_length=255))
    # answers = models.CharField(max_length=255, default=None)
    def __str__(self):
        return self.question

# class UploadedFiles(models.Model):
#     custom_user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
#     file = models.FileField(upload_to='uploads/')
#     uploaded_at = models.DateTimeField(auto_now_add=True)

#     class Meta:
#         db_table = 'login_app_uploadedfiles'

# class uploadQuestions(models.Model):
#     serial_num = models.CharField(max_length=100,unique=True) 
#     category = models.CharField(max_length=255)
#     question = models.CharField(max_length=255)
#     options = ArrayField(models.CharField(max_length=255))
#     answer = models.CharField(max_length=255, default=None)

#     def __str__(self):
#         return self.question


class ReadQuestions(models.Model):
    main_category = models.CharField(max_length=255)
    sub_category = models.CharField(max_length=255)
    serial_num = models.FloatField(max_length=50,unique=True)
    condition = models.CharField(max_length=255,default=None)
    link = models.CharField(max_length=255,default=None)
    type = models.CharField(max_length=50)
    question = models.CharField(max_length=100)
    options = models.JSONField(max_length=100)

class SaveAnswer(models.Model):
    question = models.ForeignKey(ReadQuestions, on_delete=models.CASCADE)
    response = models.TextField()

class Upload(models.Model):
    name = models.CharField(max_length=255)
    file = models.FileField(upload_to='uploads/')

    def __str__(self):
        return self.name

class f_Update(models.Model):
    filename = models.CharField(max_length=255)
    file_data = models.BinaryField()
    file_type = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.filename

class sample(models.Model):
    name = models.CharField(max_length=100)
    filename = models.CharField(max_length=255)
    file_data = models.BinaryField()
    file_type = models.CharField(max_length=100)

    def __str__(self):
        return self.filename

# class Division(models.Model):
#     category_name = models.CharField(max_length=50)

# class cement_questions(models.Model):
#     division = models.ForeignKey(Division, on_delete=models.CASCADE)
#     s_no = models.CharField(max_length=10,unique=True)
#     condition_based = models.CharField(max_length=10)   
#     main_category = models.CharField(max_length=50)
#     sub_category = models.CharField(max_length=50)
#     document_link = models.CharField(max_length=255)
#     ques_type = models.CharField(max_length=255)
#     question = models.CharField(max_length=255)
#     options = models.JSONField(max_length=100)

#     def __str__(self):
#         return self.s_no

# class FileUpload(models.Model):


class Companies_Type(models.Model):
    COMPANY_CHOICES = [
        ('Cement', 'Cement'),
        ('Iron_Steel', 'Iron & Steel'),
        ('Aluminium', 'Aluminium'),
        ('Copper', 'Copper'),
        ('Power_Plant', 'Power Plant'),
        ('Renewables', 'Renewables'),
        ('Oil_Gas', 'Oil & Gas'),
        ('Logistics_Transportation', 'Logistics & Transportation'),
    ]
    company_type = models.CharField(max_length=50, choices=COMPANY_CHOICES)
    version = models.CharField(max_length=50)

    def __str__(self):
        return self.company_type

class File_Uploads(models.Model):
    company_type = models.ForeignKey(Companies_Type,on_delete=models.CASCADE)
    filename = models.CharField(max_length=255)
    file_data = models.BinaryField()
    file_type = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.filename


class MainQuestions(models.Model):
    main_category = models.CharField(max_length=255)
    sub_category = models.CharField(max_length=255)
    serial_num = models.FloatField(max_length=50,unique=True)
    condition = models.CharField(max_length=255,default=None)
    link = models.CharField(max_length=255,default=None)
    type = models.CharField(max_length=50)
    question = models.CharField(max_length=100)
    options = models.JSONField(max_length=100)

    def __str__(self):
        return self.question

class SubQuestions(models.Model):
    main_questions = models.ForeignKey(MainQuestions,on_delete=models.CASCADE)
    main_category = models.CharField(max_length=255)
    sub_category = models.CharField(max_length=255)
    serial_num = models.FloatField(max_length=50,unique=True)
    condition = models.CharField(max_length=255,default=None)
    link = models.CharField(max_length=255,default=None)
    type = models.CharField(max_length=50)
    question = models.CharField(max_length=100)
    options = models.JSONField(max_length=100)
    
    def __str__(self):
        return self.question