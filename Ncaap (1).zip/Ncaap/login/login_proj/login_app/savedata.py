from .models import CompanyDetails, CustomUser, ContactDetails, ContactDirectory, LocationDetails, Milestone, Documents, Questions
from rest_framework.response import Response
# from .forms import DocumentForm
class AddCustomer:
    def save_company_data(user_details,user_instance):
        try:
            comapany_details = CompanyDetails(
                    custom_user=user_instance,
                    company_name=user_details.get('companyname',''),
                    company_type=user_details.get('companytype',''),
                    company_location=user_details.get('companylocation',''),
                    street=user_details.get('street',''),
                    country=user_details.get('country',''),
                    city=user_details.get('city',''),
                    zip_code=user_details.get('zip_code','')
            )
            comapany_details.save()
        except Exception as e:
            return Response({'error':e})
    
    def save_contact(contact_details, company_details_instance):
        try:
            contact_details = ContactDetails(
                    company_details=company_details_instance,
                    contact_person_name=contact_details.get('contact_person_name',''),
                    contact_person_email=contact_details.get('contact_person_email',''),
                    contact_person_designation=contact_details.get('contact_person_designation',''),
                    contact_person_mobile_number=contact_details.get('contact_person_mobile_number','')
            )
            contact_details.save()
        except Exception as e:
            return Response({'error':e})
        
    def save_directory(contact_directory,contact_instance):
        try:
             contact_directory= ContactDirectory(
                    contact_details=contact_instance,
                    name=contact_directory.get('name',''),
                    department=contact_directory.get('department',''),
                    email=contact_directory.get('email',''),
                    mobile_num=contact_directory.get('mobile_num','')
             )
             contact_directory.save()
        
        except Exception as e:
            return Response({'error':e})

    def save_location(location_detail,company_instance):
        try:
            location_detail = LocationDetails(
                    company_details=company_instance,
                    plant_name=location_detail.get('street',''),
                    country=location_detail.get('country',''),
                    city=location_detail.get('city',''),
                    zip_code=location_detail.get('zip_code','')
            )
            location_detail.save()
        except Exception as e:
            return Response({'error':e})
    
    def save_milestone(milestone_detail,company_instance):
        try:
            milestone_detail = Milestone(
                    company_details = company_instance,
                    project_expectation = milestone_detail.get('milestone','')
            )
            milestone_detail.save()
        except Exception as e:
            return Response({'error':e})
    
    def save_document(document_detail,company_instance):
        try:
            document_detail = Documents(
                    company_details=company_instance,
                    category=document_detail.get('category',''),
                    descriptions=document_detail.get('descriptions',''),
            )
            document_detail.save()
            
        except Exception as e:
            return Response({'error':e})
    
    def save_questions(question_list):
        try:
            question_list = Questions(
                serial_num = question_list['s_no'],
                # category = question_list['category'],
                # question = question_list['Question'],
                # response = question_list['Response'], 
            )
            question_list.save()
        except Exception as e:
            return Response({'error':e})
        
